const { Router } = require('express');
const { Ability } = require('../db');
const router = Router();

module.exports = router;