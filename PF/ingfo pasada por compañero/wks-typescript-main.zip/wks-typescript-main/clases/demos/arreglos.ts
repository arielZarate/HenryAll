let tupla: [string, number] = ['Mati', 29]

tupla = ['Franco', 27]

let arreglo : number[] = [1, 2, 3, 4]

let arregloStrings : string[] = ['mati', 'lamela']

let mati = arregloStrings.shift()

let arregloNumeros: Array<number> = [2, 3, 4, 5, 1]