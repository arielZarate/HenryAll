function suma(a: number, b: number): number {
    return a + b
} //que pasa si yo quisiera concatenar strings con esta funcion?