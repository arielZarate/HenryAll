function suma(a: number, b: number): number {
    return a + b
}
// Logra que esta funcion tambien concatene strings